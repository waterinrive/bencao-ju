// @ts-nocheck
import { _selfcheck, scoreFormula } from '../src/shared/score.js';
import { HERBS } from '../src/data/herbs.js';
import { PUZZLES } from '../src/data/puzzles.js';
_selfcheck();
console.log('=== selfcheck pass: 麻黄汤=方宗 ===\n');
const cases: [string, any, number][] = [
  ['麻黄汤完整方', {jun:HERBS['mahuang'],chen:HERBS['guizhi'],zuo:HERBS['xingren'],shi:HERBS['gancao']}, 0],
  ['麻黄汤精简3味(麻+杏+草)', {jun:HERBS['mahuang'],zuo:HERBS['xingren'],shi:HERBS['gancao']}, 0],
  ['桂枝稳方3味(桂+杏+草)', {jun:HERBS['guizhi'],zuo:HERBS['xingren'],shi:HERBS['gancao']}, 0],
  ['麻黄无佐2味(麻+草)', {jun:HERBS['mahuang'],shi:HERBS['gancao']}, 0],
  ['风热银翘(薄+银+翘+草)', {jun:HERBS['bohe'],chen:HERBS['jinyinhua'],zuo:HERBS['lianqiao'],shi:HERBS['gancao']}, 1],
  ['风热逆证(麻黄君温)', {jun:HERBS['mahuang'],shi:HERBS['gancao']}, 1],
  ['阳虚四逆+人参佐(附+姜+参+草)', {jun:HERBS['fuzi'],chen:HERBS['ganjiang'],zuo:HERBS['renshen'],shi:HERBS['gancao']}, 2],
  ['阳虚附子无佐2味(附+草)', {jun:HERBS['fuzi'],shi:HERBS['gancao']}, 2],
  ['阳虚干姜稳方(姜+参+草)', {jun:HERBS['ganjiang'],zuo:HERBS['renshen'],shi:HERBS['gancao']}, 2],
  ['脾虚正解(参+陈+草)', {jun:HERBS['renshen'],chen:HERBS['chenpi'],shi:HERBS['gancao']}, 3],
  ['脾虚相恶陷阱(参+莱菔子+草)', {jun:HERBS['renshen'],zuo:HERBS['laifuzi'],shi:HERBS['gancao']}, 3],
  ['脾虚相反毒发(草+海藻+陈)', {jun:HERBS['gancao'],chen:HERBS['haizao'],zuo:HERBS['chenpi']}, 3],
];
for (const [name, f, i] of cases) {
  const r = scoreFormula(f, PUZZLES[i].boss);
  console.log(`${name.padEnd(28)} → ${r.rating.padEnd(3)} ${String(r.total).padStart(3)}  (效${String(r.xiao).padStart(3)} 险${String(r.xian).padStart(2)} 雅${String(r.ya).padStart(3)})`);
}