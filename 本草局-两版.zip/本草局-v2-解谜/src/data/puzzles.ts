import type { BossCard } from '../shared/types.js';
import { FENGHAN_BIAOSHI } from './bosses.js';

// 本草·局 v2 关卡：每个病证=一个多解谜题。
// 药柜=固定候选池（不抽牌、不堆牌库——解谜不需要那套对战机制）。
// 每关池子刻意选成「有多种合法解 + 一个方宗天花板 + 至少一个陷阱」。

export const FENGRE_BIAOSHI: BossCard = {
  id: 'fengre_biaoshi', name: '风热表实证',
  flavor: '发热微恶风，咽痛口渴，脉浮数。',
  bagang: { biaoli: '表', hanre: '热', xushi: '实' },
  zhuzheng: { requireZhifa: '汗', requireGongxiao: '辛凉解表', desc: '风热袭表。' },
  jianzheng: [{ name: '咽痛', requireGongxiao: '清热泻火', worsen: 'DEBUFF' }],
  targetGuijing: '肺', hp: 40, yitu: { type: 'ATTACK', value: 0 },
};

export const YANGXU_HANJUE: BossCard = {
  id: 'yangxu_hanjue', name: '阳虚寒厥证',
  flavor: '四肢厥冷，下利清谷，脉微欲绝。',
  bagang: { biaoli: '里', hanre: '寒', xushi: '虚' },
  zhuzheng: { requireZhifa: '温', requireGongxiao: '温里散寒', desc: '心肾阳衰，阴寒内盛。' },
  jianzheng: [{ name: '气脱', requireGongxiao: '补气', worsen: 'DEBUFF' }],
  targetGuijing: '心', hp: 40, yitu: { type: 'ATTACK', value: 0 },
};

export const PIXU_QIZHI: BossCard = {
  id: 'pixu_qizhi', name: '脾虚气滞证',
  flavor: '食少腹胀，乏力便溏，舌淡苔白。',
  bagang: { biaoli: '里', hanre: '寒', xushi: '虚' },
  zhuzheng: { requireZhifa: '补', requireGongxiao: '补气', desc: '脾虚气弱，运化失司兼滞。' },
  jianzheng: [{ name: '气滞', requireGongxiao: '理气', worsen: 'DEBUFF' }],
  targetGuijing: '脾', hp: 40, yitu: { type: 'ATTACK', value: 0 },
};

export interface Puzzle {
  boss: BossCard;
  pool: string[];       // 药柜候选（herb id）
  intro: string;        // 关卡说明（读病证）
  target: string;       // 目标一句话
}

export const PUZZLES: Puzzle[] = [
  {
    boss: FENGHAN_BIAOSHI,
    pool: ['mahuang', 'guizhi', 'xingren', 'gancao', 'jinyinhua', 'chenpi'],
    intro: '风寒袭表。主证要「发汗解表」，兼证咳喘要「降逆平喘」，归经肺。',
    target: '开一剂方，解风寒表实。',
  },
  {
    boss: FENGRE_BIAOSHI,
    pool: ['bohe', 'jinyinhua', 'lianqiao', 'huangqin', 'chaihu', 'mahuang'],
    intro: '风热袭表。主证要「辛凉解表」，兼证咽痛要「清热泻火」，归经肺。当心麻黄温药逆证。',
    target: '辛凉解表，清咽。',
  },
  {
    boss: YANGXU_HANJUE,
    pool: ['fuzi', 'ganjiang', 'renshen', 'gancao', 'chenpi'],
    intro: '心肾阳衰。主证要「温里散寒」，兼证气脱要「补气」，归经心。附子大毒——无佐监制则反伤满。',
    target: '回阳救逆。',
  },
  {
    boss: PIXU_QIZHI,
    pool: ['renshen', 'gancao', 'fuling', 'chenpi', 'laifuzi', 'haizao'],
    intro: '脾虚气滞。主证要「补气」，兼证气滞要「理气」，归经脾。小心配伍禁忌：人参恶莱菔子、甘草反海藻。',
    target: '健脾理气，避禁忌。',
  },
];
