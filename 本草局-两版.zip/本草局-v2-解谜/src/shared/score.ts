import type { Hanre, Siqi } from './enums.js';
import type { HerbCard, BossCard, Formula } from './types.js';
import { pairQing } from './combat.js';

// 本草·局 v2 —— 开方解谜结算引擎
// 评分三维：效（命不命中病证）/ 险（峻烈反伤+相反禁忌）/ 雅（配伍+精简+结构）
// 同一病证因此有多解：猛药（高效高险）、稳方（中效低险）、精简（少药全覆盖高雅分）。

export interface ScoreResult {
  xiao: number;    // 效 0-100
  xian: number;    // 险（正数=扣分项）
  ya: number;      // 雅（正负）
  total: number;   // 效 − 险 + 雅
  rating: '不及格' | '及格' | '优秀' | '方宗';
  lines: string[]; // 逐步因果（教学）
  cured: string[]; // 兼证解除
}

function qiMatch(bossHanre: Hanre, qi: Siqi): { mul: number; label: string } {
  if (bossHanre === '热') {
    if (qi === '寒' || qi === '凉') return { mul: 1, label: '顺' };
    if (qi === '温' || qi === '热') return { mul: 0.4, label: '逆' };
    return { mul: 0.8, label: '中' };
  }
  if (qi === '温' || qi === '热') return { mul: 1, label: '顺' };
  if (qi === '寒' || qi === '凉') return { mul: 0.4, label: '逆' };
  return { mul: 0.8, label: '中' };
}

export function scoreFormula(f: Formula, boss: BossCard): ScoreResult {
  const lines: string[] = [];
  const all: HerbCard[] = [f.jun, f.chen, f.zuo, f.shi].filter((h): h is HerbCard => !!h);
  const placed = all.length;

  if (!f.jun) {
    return { xiao: 0, xian: 0, ya: 0, total: 0, rating: '不及格', lines: ['方中无君，药无主攻。'], cured: [] };
  }

  // —— 效 ——
  let xiao = 0;
  const jun = f.jun;
  const mainHit = jun.mainGongxiao === boss.zhuzheng.requireGongxiao;
  if (mainHit) { xiao += 40; lines.push(`君「${jun.name}」对主证「${boss.zhuzheng.requireGongxiao}」✓`); }
  else { xiao += 12; lines.push(`君「${jun.name}」（${jun.mainGongxiao}）不对主证「${boss.zhuzheng.requireGongxiao}」，药不专。`); }
  const qm = qiMatch(boss.bagang.hanre, jun.siqi);
  xiao += Math.round(15 * qm.mul);
  if (qm.mul < 1) lines.push(`四气${jun.siqi}与证（${boss.bagang.hanre}）${qm.label}，效减。`);

  const cured: string[] = [];
  for (const jz of boss.jianzheng) {
    const healer = all.find(h => h.mainGongxiao === jz.requireGongxiao || h.subGongxiao === jz.requireGongxiao);
    if (healer) { cured.push(jz.name); xiao += 15; lines.push(`兼证「${jz.name}」由「${healer.name}」解除✓`); }
    else lines.push(`兼证「${jz.name}」未治。`);
  }
  const meridianHit = all.some(h => h.guiJing.includes(boss.targetGuijing));
  if (meridianHit) { xiao += 15; lines.push(`归经${boss.targetGuijing}命中✓`); }
  else lines.push(`药力未达${boss.targetGuijing}归经。`);
  xiao = Math.min(100, xiao);

  // —— 险 ——
  let xian = 0;
  let hasXiangfan = false;
  const hasZuo = !!f.zuo;
  for (const h of all) {
    if (h.toxicity > 0) {
      const full = h.toxicity * 6;
      const v = hasZuo ? Math.round(full / 2) : full;
      xian += v;
      lines.push(`「${h.name}」峻烈（毒${h.toxicity}）${hasZuo ? '有佐监制，反伤减半' : '无佐监制，反伤满'} −${v}险`);
    }
  }
  for (let i = 0; i < all.length; i++) for (let j = i + 1; j < all.length; j++) {
    const q = pairQing(all[i]!, all[j]!);
    if (q === '相反') { hasXiangfan = true; xian += 40; lines.push(`「${all[i]!.name}」与「${all[j]!.name}」相反（十八反）！方生毒。`); }
  }

  // —— 雅 ——
  let ya = 0;
  for (let i = 0; i < all.length; i++) for (let j = i + 1; j < all.length; j++) {
    const q = pairQing(all[i]!, all[j]!);
    if (q === '相须' || q === '相使') { ya += 8; lines.push(`「${all[i]!.name}」与「${all[j]!.name}」${q}，配伍增效 +8雅`); }
    else if (q === '相恶') { ya -= 10; lines.push(`「${all[i]!.name}」与「${all[j]!.name}」相恶，互相削弱 −10雅`); }
  }
  const rolesFilled = [f.jun, f.chen, f.zuo, f.shi].filter(Boolean).length;
  if (rolesFilled === 4) { ya += 10; lines.push('君臣佐使四角色齐备 +10雅'); }
  // 药简力专：覆盖主证+全兼证+归经，且 3-4 味
  const allCovered = mainHit && cured.length === boss.jianzheng.length && meridianHit;
  if (allCovered && placed >= 3 && placed <= 4) { ya += (5 - placed) * 6; lines.push(`药简力专（${placed}味全覆盖）+雅`); }
  // 冗余：同主功效堆叠 >2 味
  const gxCount: Record<string, number> = {};
  for (const h of all) gxCount[h.mainGongxiao] = (gxCount[h.mainGongxiao] ?? 0) + 1;
  for (const k in gxCount) if (gxCount[k]! > 2) { ya -= 5; lines.push(`「${k}」堆叠过多，冗余 −5雅`); }

  let total = Math.max(0, Math.round(xiao - xian + ya));
  if (hasXiangfan) total = Math.min(total, 50); // 毒发，强制不及格
  let rating: ScoreResult['rating'] = '不及格';
  if (total >= 100) rating = '方宗';
  else if (total >= 85) rating = '优秀';
  else if (total >= 60) rating = '及格';
  return { xiao, xian, ya, total, rating, lines, cured };
}

// ponytail: 非平凡结算逻辑留一个 assert 自检；改规则后常跑防回归。
// 麻黄汤经典方应判「方宗」；若评分心脏改了，这里先红。
export function _selfcheck(): void {
  const mahuang: HerbCard = { name: '麻黄', mainGongxiao: '发汗解表', siqi: '温', guiJing: ['肺', '膀胱'], power: 12, toxicity: 1, cost: 2, peiwu: [{ drug: '桂枝', qing: '相须' }] };
  const guizhi: HerbCard = { name: '桂枝', mainGongxiao: '发汗解表', siqi: '温', guiJing: ['心', '肺', '膀胱'], power: 10, toxicity: 0, cost: 1, peiwu: [{ drug: '麻黄', qing: '相须' }] };
  const xingren: HerbCard = { name: '杏仁', mainGongxiao: '降逆平喘', siqi: '温', guiJing: ['肺', '大肠'], power: 8, toxicity: 0, cost: 1 };
  const gancao: HerbCard = { name: '甘草', mainGongxiao: '补气', siqi: '平', guiJing: ['心', '肺', '脾', '胃'], power: 5, toxicity: 0, cost: 0, peiwu: [{ drug: '海藻', qing: '相反' }] };
  const boss: BossCard = {
    id: 'fenghan_biaoshi', name: '风寒表实证', bagang: { biaoli: '表', hanre: '寒', xushi: '实' },
    zhuzheng: { requireZhifa: '汗', requireGongxiao: '发汗解表', desc: '风寒袭表。' },
    jianzheng: [{ name: '咳喘', requireGongxiao: '降逆平喘', worsen: 'DEBUFF' }],
    targetGuijing: '肺', hp: 40, yitu: { type: 'ATTACK', value: 0 },
  };
  const r = scoreFormula({ jun: mahuang, chen: guizhi, zuo: xingren, shi: gancao }, boss);
  console.assert(r.rating === '方宗', `麻黄汤应判方宗，实际 ${r.rating}/${r.total}`, r);
}
