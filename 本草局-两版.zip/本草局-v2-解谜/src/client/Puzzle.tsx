import { useEffect, useRef, useState } from 'react';
import { HERBS } from '../data/herbs.js';
import { PUZZLES } from '../data/puzzles.js';
import { scoreFormula } from '../shared/score.js';
import { _selfcheck } from '../shared/score.js';
import type { BossCard, HerbCard, Formula } from '../shared/types.js';
import './puzzle.css';

type Role = 'jun' | 'chen' | 'zuo' | 'shi';
const ROLES: Role[] = ['jun', 'chen', 'zuo', 'shi'];
const ROLE_NAME: Record<Role, string> = { jun: '君', chen: '臣', zuo: '佐', shi: '使' };
const ROLE_TIP: Record<Role, string> = {
  jun: '君·主攻主证', chen: '臣·助君治兼', zuo: '佐·减毒治次', shi: '使·引经调和',
};
const SIQI_COLOR: Record<string, string> = { 寒: '#3a6ea5', 凉: '#5a9bd4', 温: '#c1440e', 热: '#8b1a1a', 平: '#6a6a6a' };

export function Puzzle() {
  const [pi, setPi] = useState(0);
  const [formula, setFormula] = useState<Partial<Record<Role, string>>>({});
  const [result, setResult] = useState<ReturnType<typeof scoreFormula> | null>(null);
  const [flash, setFlash] = useState(false);
  const [countTo, setCountTo] = useState(0);
  const puzzle = PUZZLES[pi]!;
  const boss = puzzle.boss;
  const used = new Set(Object.values(formula).filter(Boolean) as string[]);

  useEffect(() => { _selfcheck(); }, []); // 引擎自检随首屏跑一次

  function buildFormula(f: Partial<Record<Role, string>>): Formula {
    const out: Formula = {};
    for (const r of ROLES) if (f[r]) out[r] = HERBS[f[r] as string];
    return out;
  }
  function place(key: string) {
    if (used.has(key)) return;
    const role = ROLES.find(r => !formula[r]);
    if (!role) return;
    setFormula({ ...formula, [role]: key });
    setResult(null);
  }
  function placeAt(role: Role, key: string) {
    if (used.has(key) && formula[role] !== key) return;
    const prev = formula[role];
    const next = { ...formula, [role]: key };
    setFormula(next);
    setResult(null);
  }
  function takeBack(r: Role) { setFormula({ ...formula, [r]: undefined }); setResult(null); }
  function clearFormula() { setFormula({}); setResult(null); }
  function selectPuzzle(i: number) { setPi(i); setFormula({}); setResult(null); setCountTo(0); }
  function resolve() {
    const r = scoreFormula(buildFormula(formula), boss);
    setResult(r);
    setFlash(true);
    setCountTo(0);
    setTimeout(() => setFlash(false), 700);
  }

  // 评分总数 count-up 动画
  useEffect(() => {
    if (!result) return;
    const target = result.total;
    let raf = 0; const start = performance.now(); const dur = 600;
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / dur);
      setCountTo(Math.round(target * (0.4 + 0.6 * (1 - Math.pow(1 - t, 3)))));
      if (t < 1) raf = requestAnimationFrame(tick); else setCountTo(target);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [result]);

  const filledCount = Object.values(formula).filter(Boolean).length;

  return (
    <div className="pz-board">
      <header className="pz-top">
        <h1>本草·局 <span className="pz-sub">开方解谜</span></h1>
        <div className="pz-nav">
          {PUZZLES.map((p, i) => (
            <button key={p.boss.id} className={`pz-tab ${i === pi ? 'on' : ''}`} onClick={() => selectPuzzle(i)}>
              {i + 1}. {p.boss.name}
            </button>
          ))}
        </div>
      </header>

      <BossPanel boss={boss} intro={puzzle.intro} target={puzzle.target} />

      <div className="pz-stage">
        {ROLES.map(r => (
          <Slot key={r} role={r}
            herb={formula[r] ? (HERBS[formula[r] as string] ?? null) : null}
            herbKey={formula[r] as string | undefined}
            filled={!!formula[r]}
            flash={flash}
            onClick={() => formula[r] && takeBack(r)}
          />
        ))}
      </div>

      <div className="pz-actions">
        <button className="pz-btn primary" onClick={resolve} disabled={filledCount === 0}>⚔ 结算评分</button>
        <button className="pz-btn ghost" onClick={clearFormula} disabled={filledCount === 0}>✕ 清空</button>
      </div>

      {result && (
        <ScorePanel r={result} countTo={countTo} boss={boss} />
      )}

      <Cabinet pool={puzzle.pool} used={used} onPlace={place} onDrop={(role, key) => placeAt(role, key)} />
    </div>
  );
}

function BossPanel({ boss, intro, target }: { boss: BossCard; intro: string; target: string }) {
  return (
    <div className="pz-boss">
      <div className="pz-boss-head">
        <span className="pz-seal">证</span>
        <div>
          <div className="pz-boss-name">{boss.name}</div>
          {boss.flavor && <div className="pz-flavor">{boss.flavor}</div>}
        </div>
      </div>
      <div className="pz-bagang">
        <span className="bg-chip">{boss.bagang.biaoli}</span>
        <span className="bg-chip">{boss.bagang.hanre}</span>
        <span className="bg-chip">{boss.bagang.xushi}</span>
      </div>
      <div className="pz-req">
        <div className="pz-req-row"><small>主证·治法</small><b>{boss.zhuzheng.requireZhifa}</b><b className="gx">{boss.zhuzheng.requireGongxiao}</b></div>
        {boss.jianzheng.map(j => <div key={j.name} className="pz-req-row"><small>兼证·{j.name}</small><b className="gx">{j.requireGongxiao}</b></div>)}
        <div className="pz-req-row"><small>归经</small><b>{boss.targetGuijing}</b></div>
      </div>
      <p className="pz-intro">{intro}</p>
      <p className="pz-target">目标 · {target}</p>
    </div>
  );
}

function Slot({ role, herb, herbKey, filled, flash, onClick }: {
  role: Role; herb: HerbCard | null; herbKey?: string; filled: boolean; flash: boolean; onClick: () => void;
}) {
  const qcol = herb ? (SIQI_COLOR[herb.siqi] ?? '#6a6a6a') : '#6a6a6a';
  return (
    <div className={`pz-slot ${filled ? 'filled' : 'empty'} ${flash && filled ? 'hit' : ''}`} onClick={onClick}>
      <div className="pz-slot-role">{ROLE_NAME[role]}</div>
      <div className="pz-slot-tip">{ROLE_TIP[role]}</div>
      {herb ? (
        <div className="pz-card">
          <div className="pz-card-name">{herb.name}</div>
          <div className="pz-card-gx">{herb.mainGongxiao}</div>
          <div className="pz-card-stat">
            <span className="pz-power">{herb.power}</span>
            <span className="pz-siqi" style={{ color: qcol }}>{herb.siqi}</span>
            {herb.toxicity > 0 && <span className="pz-tox">毒{herb.toxicity}</span>}
          </div>
        </div>
      ) : (
        <div className="pz-slot-empty">选药入位</div>
      )}
    </div>
  );
}

function Cabinet({ pool, used, onPlace, onDrop }: {
  pool: string[]; used: Set<string>; onPlace: (k: string) => void; onDrop: (r: Role, k: string) => void;
}) {
  return (
    <div className="pz-cabinet">
      <div className="pz-cab-title">药柜 · 点药入位（或拖到指定角色位）</div>
      <div className="pz-cab-grid">
        {pool.map(k => {
          const h = HERBS[k]; if (!h) return null;
          const isUsed = used.has(k);
          const qcol = SIQI_COLOR[h.siqi] ?? '#6a6a6a';
          return (
            <div key={k} className={`pz-herb ${isUsed ? 'used' : ''}`}
              draggable={!isUsed}
              onDragStart={(e) => { e.dataTransfer.setData('text/plain', k); e.dataTransfer.effectAllowed = 'move'; }}
              onClick={() => onPlace(k)}
            >
              <div className="pz-h-name">{h.name}</div>
              <div className="pz-h-gx">{h.mainGongxiao}{h.subGongxiao ? ` / ${h.subGongxiao}` : ''}</div>
              <div className="pz-h-stat">
                <span className="pz-power">{h.power}</span>
                <span className="pz-siqi" style={{ color: qcol }}>{h.siqi}</span>
                {h.toxicity > 0 && <span className="pz-tox">毒{h.toxicity}</span>}
              </div>
              <div className="pz-h-gui">归 {h.guiJing.join('·')}</div>
              {h.peiwu && h.peiwu.length > 0 && (
                <div className="pz-h-pw">{h.peiwu.map(p => `${p.drug}${p.qing}`).join(' ')}</div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function ScorePanel({ r, countTo, boss }: { r: ReturnType<typeof scoreFormula>; countTo: number; boss: BossCard }) {
  const ratingCls = r.rating === '方宗' ? 'gold' : r.rating === '优秀' ? 'good' : r.rating === '及格' ? 'ok' : 'bad';
  return (
    <div className="pz-score">
      <div className="pz-bars">
        <Bar label="效" v={r.xiao} max={100} cls="xiao" />
        <Bar label="险" v={r.xian} max={40} cls="xian" invert />
        <Bar label="雅" v={Math.max(0, r.ya)} max={30} cls="ya" />
      </div>
      <div className="pz-total-row">
        <div className="pz-total">{countTo}</div>
        <div className={`pz-rating ${ratingCls}`}>{r.rating}</div>
      </div>
      <ul className="pz-lines">
        {r.lines.map((s, i) => <li key={i}>{s}</li>)}
      </ul>
      {r.rating === '方宗' && <div className="pz-perfect">方宗·经方大成</div>}
    </div>
  );
}

function Bar({ label, v, max, cls, invert }: { label: string; v: number; max: number; cls: string; invert?: boolean }) {
  const pct = Math.min(100, (v / max) * 100);
  return (
    <div className={`pz-bar ${cls}`}>
      <span className="pz-bar-l">{label}</span>
      <div className="pz-bar-track"><div className={`pz-bar-fill ${invert ? 'inv' : ''}`} style={{ width: `${pct}%` }} /></div>
      <span className="pz-bar-v">{v}</span>
    </div>
  );
}
