import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { Puzzle } from './Puzzle.js';
import './styles.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Puzzle />
  </StrictMode>,
);
