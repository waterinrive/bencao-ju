本草·局 — 两版源码包
======================

v1 对战 demo  ·  v2 开方解谜
两个独立目录，各自 `pnpm install` 后运行。

——————————————————————————————
本草局-v1-对战
  黑客松完整 demo：教学关（手把手麻黄汤）+ 自由对局（知乎搜索生成今日病证 BOSS）
  启动：
    pnpm install
    pnpm gen:boss        # 预生成今日 BOSS（需 .env 配知乎 Access Secret；无则自由对局回退教学关）
    pnpm dev:server     # 后端 :3000（/api/today-boss · /api/ask-mentor）
    pnpm dev            # 前端 :5173
  自由对局需知乎开放平台凭证（见 .env.example）；教学关离线可玩。

本草局-v2-解谜
  重做版：开方解谜。一个病证=多解谜题，效/险/雅三维评分，4 关。
  纯前端，结算在浏览器跑，不需后端/不需凭证。
  启动：
    pnpm install
    pnpm dev            # 前端 :5173，开即玩
  自检：pnpm test（结算引擎 assert）/ npx tsx scripts/check-score.ts（评分平衡）

两版共享：src/data（中药/病证）+ src/shared（结算引擎）。v2 的 score.ts 是新评分引擎，combat.ts 是 v1 的对战引擎，互不干扰。
